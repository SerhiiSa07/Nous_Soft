# File paths
NOUS_API_FILE_PATH = "user_files/nous_api.txt"
PROXY_FILE_PATH = "user_files/proxies.txt"
HYPERBOLIC_API_FILE_PATH = "user_files/hyperbolic_api.txt"

logo = r"""                                      
 _______ _______ _______ _______ _    _ _     _
 |______    |       |    |_____|  \  /  |____/ 
 |          |       |    |     |   \/   |    \_
 """

PROJECT = """
_  _ ____ _  _ ____    _  _    _  _ _   _ ___  ____ ____ ___  ____ _    _ ____ 
|\ | |  | |  | [__      \/     |__|  \_/  |__] |___ |__/ |__] |  | |    | |    
| \| |__| |__| ___]    _/\_    |  |   |   |    |___ |  \ |__] |__| |___ | |___ 

"""